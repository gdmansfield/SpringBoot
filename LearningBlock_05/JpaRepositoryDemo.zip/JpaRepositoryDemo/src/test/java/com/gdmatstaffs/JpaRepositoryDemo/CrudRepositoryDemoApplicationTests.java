package com.gdmatstaffs.JpaRepositoryDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudRepositoryDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
