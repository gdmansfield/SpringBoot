package com.gdmatstaffs.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordcountApplicationTests {

	@Test
	void contextLoads() {
	}

}
