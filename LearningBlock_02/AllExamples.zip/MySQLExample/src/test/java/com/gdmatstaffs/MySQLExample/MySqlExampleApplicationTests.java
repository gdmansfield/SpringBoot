package com.gdmatstaffs.MySQLExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySqlExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
