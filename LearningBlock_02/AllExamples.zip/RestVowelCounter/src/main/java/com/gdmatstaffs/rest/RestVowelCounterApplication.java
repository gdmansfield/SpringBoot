package com.gdmatstaffs.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestVowelCounterApplication
{

	public static void main(String[] args) {
		SpringApplication.run(RestVowelCounterApplication.class, args);
	}

}
