package com.gdmatstaffs.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VowelCountWithHtmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
