package com.gdmatstaffs.demoJSON;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
