package com.gdmatstaffs.JUnitDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JUnitDemoApplication
{

	public static void main(String[] args) {
		SpringApplication.run(JUnitDemoApplication.class, args);
	}

}
