package com.gdmatstaffs.CrudRepositoryDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudRepositoryDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudRepositoryDemoApplication.class, args);
	}

}
